﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;

namespace RentMyWrox.Models
{
    public class HobbyReportItem
    {
        public string Name { get; set; }

        public string BirthRange { get; set; }

        public int Total { get; set; }
    }
}