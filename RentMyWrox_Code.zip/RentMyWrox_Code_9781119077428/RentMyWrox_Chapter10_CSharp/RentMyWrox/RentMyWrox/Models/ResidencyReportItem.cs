﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;

namespace RentMyWrox.Models
{
    public class ResidencyReportItem
    {
        public string BirthRange { get; set; }

        public int Total { get; set; }

        public int AverageMonths { get; set; }
    }
}