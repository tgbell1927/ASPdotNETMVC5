﻿using System.Web.UI;

namespace RentMyWrox.Account
{
    public partial class ResetPasswordConfirmation : Page
    {
    }
}